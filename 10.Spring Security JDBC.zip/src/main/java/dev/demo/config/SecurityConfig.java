package dev.demo.config;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.provisioning.JdbcUserDetailsManager;
import org.springframework.security.provisioning.UserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {
	
	@Bean
	UserDetailsManager userDetailsManager(DataSource dataSource) {
		UserDetails haolv1 = User.builder().username("haolv1").password("{noop}abc123").roles("USER").build();
		UserDetails haolv2 = User.builder().username("haolv2").password("{noop}abc123").roles("USER", "MANAGER").build();
		UserDetails haolv3 = User.builder().username("haolv3").password("{noop}abc123").roles("USER", "MANAGER", "ADMIN").build();

		JdbcUserDetailsManager users = new JdbcUserDetailsManager(dataSource);
		if (!users.userExists(haolv1.getUsername())) {
			users.createUser(haolv1);
		}
		if (!users.userExists(haolv1.getUsername())) {
			users.createUser(haolv2);
		}
		if (!users.userExists(haolv1.getUsername())) {
			users.createUser(haolv3);
		}

		return users;
	}

	@Bean
	SecurityFilterChain filterChain(HttpSecurity http) throws Exception {

		http.authorizeHttpRequests(configurer -> 
			configurer
				.requestMatchers(HttpMethod.GET, "/api/employee").hasRole("USER")
				.requestMatchers(HttpMethod.POST, "/api/employee").hasRole("MANAGER")
				.requestMatchers(HttpMethod.PUT, "/api/employee/**").hasRole("MANAGER")
				.requestMatchers(HttpMethod.DELETE, "/api/employee/**").hasRole("ADMIN")
		);
		http.httpBasic(Customizer.withDefaults());
		http.csrf(csrf -> csrf.disable());

		return http.build();
	}
}
