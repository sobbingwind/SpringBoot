package dev.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoAuthServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoAuthServerApplication.class, args);
	}

}
