package dev.demo.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableMethodSecurity
public class SecurityConfig {
	
	@Bean
	InMemoryUserDetailsManager userDetailsManager() {

		UserDetails haolv1 = User.builder().username("haolv1").password("{noop}test123").roles("USER").build();

		UserDetails haolv2 = User.builder().username("haolv2").password("{noop}test123").roles("USER", "MANAGER").build();

		return new InMemoryUserDetailsManager(haolv1, haolv2);
	}

	@Bean
	SecurityFilterChain defaultSecurityFilterChain(HttpSecurity http) throws Exception {
	    http
	        .authorizeHttpRequests(authorizeRequests ->
	            authorizeRequests.anyRequest().authenticated()
	        )
	        .formLogin(Customizer.withDefaults());
		return http.build();
	}
}
