--
-- Inserting data for table `members`
--
--
INSERT INTO `members`
VALUES
('haolv1','{noop}abc123',1),
('haolv2','{noop}abc123',1),
('haolv3','{noop}abc123',1);

--
-- Inserting data for table `roles`
--
INSERT INTO `roles`
VALUES
('haolv1','ROLE_USER'),
('haolv2','ROLE_USER'),
('haolv2','ROLE_MANAGER'),
('haolv3','ROLE_USER'),
('haolv3','ROLE_MANAGER'),
('haolv3','ROLE_ADMIN');