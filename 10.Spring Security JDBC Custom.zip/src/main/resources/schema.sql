USE `demo_securiry_custom`;

DROP TABLE IF EXISTS `roles`;
DROP TABLE IF EXISTS `members`;

--
-- Table structure for table `members`
--
CREATE TABLE `members` (
  `username` varchar(50) NOT NULL,
  `password` char(100) NOT NULL,
  `active` tinyint NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;


--
-- Table structure for table `roles`
--
CREATE TABLE `roles` (
  `username` varchar(50) NOT NULL,
  `role` varchar(50) NOT NULL,
  UNIQUE KEY `ix_auth_username` (`username`,`role`),
  CONSTRAINT `fk_roles_members` FOREIGN KEY (`username`) REFERENCES `members` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
